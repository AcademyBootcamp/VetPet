package com.example.login_vetpet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
