import 'package:flutter/material.dart';

const kPrimaryColor = Color(0XFFBF360C);
const kPrimaryLightColor = Color(0xFFFFAB91);