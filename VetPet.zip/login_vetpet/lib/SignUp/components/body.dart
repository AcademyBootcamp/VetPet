import 'package:flutter/material.dart';
import 'package:login_vetpet/components/rounded_button.dart';
import 'package:login_vetpet/login/login_screen.dart';

import '../../constants.dart';
import 'background.dart';
import 'or_divider.dart';

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context){
    Size size = MediaQuery.of(context).size;
    return Background(
        child:SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Text(
                "SIGN UP",
               style: TextStyle(
                   fontWeight: FontWeight.bold),
              ),
               Image.asset("Assets/images/signup.png",
               ),
                // SizedBox(height: size.height*0.001),
           RoundedInputField(
                hintText: "Your Email",
                onChanged: (value) {},
              ),
                 SizedBox(height: size.height * 0.015),
              RoundedPasswordField(
                  onChanged: (value) {},
              ),
                // SizedBox(height: size.height * 0.15),
              RoundedButton(
                text:"SIGN UP",
                press: () {},
              ),
               // SizedBox(height: size.height*0.3),
              AlreadyHaveAnAccountCheck(
                login: false,
                press: () {
                Navigator.push(
                context,
                MaterialPageRoute(
                builder: (context){
                  return LoginScreen();
                },
              ),
            );
          },
       ),
           OrDivider(),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  socalicon(
                    iconSrc: "Assets/icons/facebook.png",
                    press: () {},
                  ),
                  socalicon(
                    iconSrc: "Assets/icons/twitter.png",
                    press: () {},
                  ),
                  socalicon(
                    iconSrc: "Assets/icons/google.png",
                    press: () {},
                  ),
                ],
              ),
      ],
     ),
        ),
    );
  }
}

class socalicon extends StatelessWidget {
  final String iconSrc;
   final Function()  press;
  const socalicon({
    Key? key,
    required this.iconSrc,
    required this.press,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: press,
      child: Container(
      margin: EdgeInsets.symmetric(horizontal:10),
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        border: Border.all(
          width: 2,
          color: kPrimaryLightColor,
        ),
        shape: BoxShape.circle
      ),
      child: Image.asset(iconSrc,
        height:20,
        width:20,
      ),
                ),
    );
  }
}

