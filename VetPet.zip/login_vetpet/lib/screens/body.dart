import 'package:flutter/material.dart';
import 'package:login_vetpet/SignUp/signup_screen.dart';
import 'package:login_vetpet/components/rounded_button.dart';
import 'package:login_vetpet/constants.dart';
import 'package:login_vetpet/login/login_screen.dart';

import 'background.dart';

class Body extends StatelessWidget {
  const Body({
    Key?key,
  }) : super(key: key);


  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Background(
      child: SingleChildScrollView(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            "Welcome to VetPet",
            style: TextStyle(height: 15, fontSize: 30),
          ),
          RoundedButton(
            text: "LOG IN",
            press: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                builder: (context) {
                  return LoginScreen();
                  },
                ),
              );
            },
          ),
          RoundedButton(
            text: "SIGN UP",
            color:kPrimaryLightColor,
            textColor: Colors.black,
            press: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context){
                    return SignUpScreen();

                  },
                ),
              );
            },
          ),
         ],
       ),
      ),
     );
  }
}