import 'package:flutter/material.dart';
import 'package:login_vetpet/SignUp/signup_screen.dart';
import 'package:login_vetpet/components/rounded_button.dart';
import 'package:login_vetpet/constants.dart';
import 'package:login_vetpet/screens/body.dart';

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}

class Body extends StatelessWidget {
  const Body({
    Key? key,
  }) : super(key: key);


  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return background_login(
        child:SingleChildScrollView(
        child: Column(
           mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
          "LOG IN",
          style: TextStyle(
              fontWeight: FontWeight.bold),
          ),
           Image.asset("Assets/images/loginpage1.png",
             width: 700,
           ),
          // Image.asset("Assets/images/login2.png",
            // height: size.height * 0.5,


          SizedBox(height: size.height * 0),
          RoundedInputField(
            hintText: "Email",
            onChanged: (value){},
          ),
          RoundedPasswordField(
              onChanged: (value) {},
          ),
          RoundedButton(
            text: "LOG IN",
            press: () {},
          ),
          SizedBox(height: size.height * 0.03),
          AlreadyHaveAnAccountCheck(
            press: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) {
                    return SignUpScreen();
                  },
                ),
              );
            },
          ),
     ],
    ),
      ),
   );
  }
}

class AlreadyHaveAnAccountCheck extends StatelessWidget {
  final bool login;
  final Function press;
  const AlreadyHaveAnAccountCheck({
    Key? key,
    this.login = true,
    required this.press,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
      Text(
        login ? "Don't have an account?" : "Already have an account? ",
         style: TextStyle(color: kPrimaryColor),
      ),
      GestureDetector(
        onTap:() => press,
        child: Text(
          login ? "Sign Up" : "Sign In",
          style: TextStyle(
          color:kPrimaryColor,
          fontWeight: FontWeight.bold,
          ),
      ),
     )
    ],
       );
  }
}

class RoundedPasswordField extends StatelessWidget {
  final ValueChanged<String> onChanged;
  const RoundedPasswordField({
    Key? key,
    required this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextFieldContainer(
      child: TextField(
        obscureText: true,
        decoration: InputDecoration(
          hintText: "Password",
      ),
      ),
    );
  }
}

class RoundedInputField extends StatelessWidget {
  final String hintText;
  final ValueChanged<String> onChanged;
  const RoundedInputField({
    Key? key,
    required this.hintText,
    required this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextFieldContainer(
      child: TextField(
        obscureText: false,
        decoration: InputDecoration(
          hintText:"Your Email",
        border: InputBorder.none,
      ),
      ),
    );
  }
}

class TextFieldContainer extends StatelessWidget {
  final Widget child;
  const TextFieldContainer({
    Key? key,
    required this.child,
  }) : super(key: key);


  @override
  Widget build(BuildContext context) {
    Size size= MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.symmetric(vertical:10),
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
      width: size.width  *0.8,
      decoration: BoxDecoration(
        color: kPrimaryLightColor,
        borderRadius: BorderRadius.circular(40),
      ),
      child: child,

    );
  }
}

class background_login extends StatelessWidget {
  final Widget child;
  const background_login({
    Key? key,
    required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size= MediaQuery.of(context).size;
    return Container(
      width:double.infinity,
      height: size.height,
      child: Stack(
        children: <Widget>[
          child,
        ],
      ),
    );
  }
}

